/*
 * Auteurs : Dubas, Pereira
 * Projet  : Voiture � d�tecteurs
 * Date    : 21.02.2018 
 * Version : 1.0
 */

using System;
using Microsoft.SPOT;
// A ajouter
using Microsoft.SPOT.Hardware;
using GHI.Pins;
using device = GHI.Pins.FEZSpider;

namespace teslaX
{
    public class Program
    {
        #region debug
        public static bool ifDebug;
        public static OutputPort debugLed;
        public static InputPort debugBtn;
        public static bool currentDebugBtnValue;
        public static bool oldDebugBtnValue;
        #endregion

        const int VITESSE_MAX_G = 1390;
        const int VITESSE_MAX_D = 1610;

        // Entr�es
        public static AnalogInput capteurFrontal;
        public static AnalogInput capteurGauche;
        public static AnalogInput capteurDroite;

        // Sorties
        public static PWM roueGauche;
        public static PWM roueDroite;

        public static void Main()
        {
            #region debug
            debugLed = new OutputPort(device.DebugLed, false);
            debugBtn = new InputPort(device.Socket6.Pin3, false, Port.ResistorMode.Disabled);
            ifDebug = false;
            currentDebugBtnValue = false;
            oldDebugBtnValue = false;
            #endregion

            // Entr�es
            capteurFrontal = new AnalogInput(device.Socket9.AnalogInput3);
            capteurGauche = new AnalogInput(device.Socket9.AnalogInput4);
            capteurDroite = new AnalogInput(device.Socket9.AnalogInput5);

            // Sorties
            //roueDroite = new PWM(device.Socket11.Pwm7, 50, VITESSE_MAX_D, false);
            //roueGauche = new PWM(device.Socket11.Pwm8, 50, VITESSE_MAX_G, false);

            roueDroite = new PWM(device.Socket11.Pwm7, 2500, VITESSE_MAX_D, PWM.ScaleFactor.Microseconds, false);
            roueGauche = new PWM(device.Socket11.Pwm8, 2500, VITESSE_MAX_G, PWM.ScaleFactor.Microseconds, false);

            roueGauche.Start();
            roueDroite.Start();

            while (true)
            {
                #region debug
                currentDebugBtnValue = debugBtn.Read();
                if (currentDebugBtnValue == false && oldDebugBtnValue == true)
                {
                    debugLed.Write(!debugLed.Read());
                    roueDroite.Duration -= 5;
                    roueGauche.Duration += 5;
                }

                oldDebugBtnValue = currentDebugBtnValue;
                #endregion

                if (capteurFrontal.Read() > 0.8)
                {
                    roueGauche.Duration = roueDroite.Duration;
                    roueDroite.Duration = roueGauche.Duration;
                }
                else if (capteurFrontal.Read() < 0.4)
                {
                    roueGauche.Duration = VITESSE_MAX_G;
                    roueDroite.Duration = VITESSE_MAX_D;
                }

                /*if (capteurDroite.Read() > 0.8)
                {
                    roueGauche.DutyCycle = 0.1;
                }
                else
                {
                    roueGauche.DutyCycle = VITESSE_MAX_G;
                }

                if (capteurGauche.Read() > 0.8)
                {
                    roueDroite.DutyCycle = -0.1;
                }
                else
                {
                    roueDroite.DutyCycle = VITESSE_MAX_D;
                }*/

                //Debug.Print("Capteurs : " + capteurDroite.Read() + " || " + capteurFrontal.Read() + " || " + capteurGauche.Read());
                Debug.Print("Moteurs : " + roueDroite.Duration.ToString() + " || " + roueGauche.Duration.ToString());
            }
        }
    }
}

/*
 * Auteurs : Dubas, Pereira
 * Projet  : Voiture � d�tecteurs
 * Date    : 21.02.2018 
 * Version : 1.0
 */

using System;
using Microsoft.SPOT;
// A ajouter
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;
using GHI.Pins;
using device = GHI.Pins.FEZSpider;

namespace teslaX
{
    public class Program
    {
        #region debug
        public static bool ifDebug;
        public static OutputPort debugLed;
        public static InputPort debugBtn;
        public static bool currentDebugBtnValue;
        public static bool oldDebugBtnValue;
        #endregion

        // Entr�es
        public static AnalogInput capteurFrontal;
        public static AnalogInput capteurGauche;
        public static AnalogInput capteurDroite;

        // Sorties
        public static PWM roueGauche;
        public static PWM roueDroite;

        public static void Main()
        {
            #region debug
            debugLed = new OutputPort(device.DebugLed, false);
            debugBtn = new InputPort(device.Socket12.Pin3, false, Port.ResistorMode.Disabled);
            ifDebug = false;
            currentDebugBtnValue = false;
            oldDebugBtnValue = false;
            #endregion

            // Entr�es
            capteurFrontal = new AnalogInput(device.Socket9.AnalogInput3);
            capteurGauche = new AnalogInput(device.Socket9.AnalogInput4);
            capteurDroite = new AnalogInput(device.Socket9.AnalogInput5);

            // Sorties
            roueGauche = new PWM(device.Socket11.Pwm7, 10000, 0.05, false);
            roueDroite = new PWM(device.Socket11.Pwm8, 10000, 0.05, false);

            while (true)
            {
                #region debug
                currentDebugBtnValue = debugBtn.Read();
                if (currentDebugBtnValue == false && oldDebugBtnValue == true)
                {
                    debugLed.Write(!debugLed.Read());
                    ifDebug = debugLed.Read();
                }

                oldDebugBtnValue = currentDebugBtnValue;

                if (ifDebug)
                {
                    Debug.Print("Capteurs : " + capteurDroite.Read() + " || " + capteurFrontal.Read() + " || " + capteurGauche.Read());
                }
                #endregion

                
            }
        }
    }
}
